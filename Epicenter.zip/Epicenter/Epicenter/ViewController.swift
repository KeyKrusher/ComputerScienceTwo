//
//  ViewController.swift
//  Epicenter
//
//  Created by period2 on 2/15/17.
//  Copyright © 2017 period2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var instagramView: UIView!
    @IBOutlet weak var facebookView: UIView!
    @IBOutlet weak var twitterView: UIView!
    @IBOutlet weak var rssView: UIView!
    
    @IBOutlet var instagramTapped: UITapGestureRecognizer!
    @IBOutlet var facebookTapped: UITapGestureRecognizer!
    @IBOutlet var twitterTapped: UITapGestureRecognizer!
    @IBOutlet var rssTapped: UITapGestureRecognizer!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        instagramView.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "instagramLogo"))
        facebookView.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "facebookLogo"))
        twitterView.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "twitterLogo"))
        rssView.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "rssLogo"))
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
    }
    func handleInstagramTapped(sender: UITapGestureRecognizer) {
        
    }
    func handleFacebookTapped(sender: UITapGestureRecognizer) {
        
    }
    func handleTwitterTapped(sender: UITapGestureRecognizer) {
        
    }
    func handleRssTapped(sender: UITapGestureRecognizer) {
        
    }
}

