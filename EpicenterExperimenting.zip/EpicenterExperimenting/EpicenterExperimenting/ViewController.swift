//
//  ViewController.swift
//  EpicenterExperimenting
//
//  Created by period2 on 2/9/17.
//  Copyright © 2017 period2. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {
    @IBOutlet weak var webView: UIWebView!
    @IBAction func refreshButton(_ sender: UIButton) {
        webView.reload()
    }
    @IBOutlet weak var URLTextField: UITextField!
    
    @IBAction func GoButton(_ sender: UIButton) {
        let url = URLTextField.text!
        webView.loadRequest(URLRequest(url: NSURL(string: url)! as URL) as URLRequest)
    }
    @IBAction func backButton(_ sender: UIButton) {
        if webView.canGoBack {
            webView.goBack()
        }
        else {
            exit(1)
        }
    }
    @IBAction func ForwardButton(_ sender: UIButton) {
        if webView.canGoForward {
            webView.goForward()
        }
        else {
            exit(1)
        }
    }
    @IBAction func stopButton(_ sender: UIButton) {
        webView.stopLoading()
    }
    override func viewDidLoad() {
        // Make the url box show the current URL in the background faded text
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        webView.loadRequest(URLRequest(url: NSURL(string: "http://www.google.com")! as URL) as URLRequest)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

